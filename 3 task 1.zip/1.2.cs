﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //12
            //int A = 123;
            //Console.WriteLine($"12) = {(A >= 100) && (A <= 999)}");

            //13
            //int A = 40, B = 46, C = 44;
            //Console.WriteLine($"13) = {((A < 45) && (B >= 45) && (C >= 45)) || ((A >= 45) && (B < 45) && (C >= 45)) || ((A >= 45) && (B >= 45) && (C < 45))}");

            //14
            //int A = 30;
            //Console.WriteLine($"14) = {(A % 3 == 0) && (A % 10 == 0)}");

            //15
            //int A = 100;
            //Console.WriteLine($"15) = {((A >= -137) && (A <= -51)) || ((A >= 55) && (A <= 123))}");

            //16
            //int X = 5, Y = 10, Z = 15;
            //Console.WriteLine($"16) = {((X % 5 == 0) && (Y % 5 != 0) && (Z % 5 != 0)) || ((X % 5 != 0) && (Y % 5 == 0) && (Z % 5 != 0)) || ((X % 5 != 0) && (Y % 5 != 0) && (Z % 5 == 0))}");

            //17
            //int X = 81, Y = 70, Z = 90;
            //Console.WriteLine($"17) = {(X > 80) || (Y > 80) || (Z > 80)}");

            //18
            //bool A = true, B = false, C = true;
            //Console.WriteLine($"а) = {A && !B || C}");
            //Console.WriteLine($"б) = {!(A || B) || C}");
            //Console.WriteLine($"в) = {A || !(B && C)}");

            //20
            //double X = 2;
            //Console.WriteLine($"20) = {(Math.Pow(X, 2) - Math.Pow(X - 3, 2)) != 0}");

            //21
            //bool X = false, Y = false, Z = true;
            //Console.WriteLine($"а) = {X && !Y || Z}");
            //Console.WriteLine($"б) = {X && !(Y || Z)}");
            //Console.WriteLine($"в) = {X || !(Y || Z)}");

            //22
            //double x = 3, y = 4;
            //Console.WriteLine($"а) = {!(x <= -5 && x >= 5)}");
            //Console.WriteLine($"б) = {(y >= -3.5 && y <= 8.1) && (x != 0)}");

            //23
            //int A = 1;
            //Console.WriteLine($"23) = {!((A >= -10 && A <= -1) || (A >= 2 && A <= 15))}");

            //24
            //int A = 1234;
            //Console.WriteLine($"24) = {(A >= 1000) && (A <= 9999) && (A != 4999)}");

            //25
            //double A = 10, B = 5, C = 20;
            //Console.WriteLine($"25) = {(A > B) || (A > C / 5)}");

            //26
            //double x = 8, y = 5;
            //Console.WriteLine($"а) = {!(x <= 0 && x <= 5)}");
            //Console.WriteLine($"б) = {(y > 0 && y <= 6) && (x > 7)}");

            //27
            //double x = 4;
            //Console.WriteLine($"а) = {(x > 3) || (x < -1)}");
        }
    }
}